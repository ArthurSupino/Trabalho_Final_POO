package Cinemas;

public class CinemaDelRey extends Cinema {
    private static CinemaDelRey instancia;
    private final double descontoEstudante; 

    private CinemaDelRey() {
        super(1, "Cinema Del Rey", "Av. Presidente Carlos Luz, 3001, Belo Horizonte - MG");
        this.descontoEstudante = 0.15; 
    }

    public static CinemaDelRey getInstancia() {
        if (instancia == null) {
            instancia = new CinemaDelRey();
        }
        return instancia;
    }

    public double calcularPrecoComDesconto(double precoBase) {
        return precoBase - (precoBase * descontoEstudante);
    }

    public double getDescontoEstudante() {
        return descontoEstudante;
    }
}
