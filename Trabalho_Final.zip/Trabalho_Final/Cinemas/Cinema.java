package Cinemas;
import java.util.ArrayList;
import java.util.List;
import Componentes_do_Cinema.*;

public abstract class Cinema {
    private int id_cinema;
    private String nome_cinema;
    private String endereco;
    private List<Sala> salas;
    private static List<Cinema> cinemas = new ArrayList<>();

    public Cinema(int id, String nome, String local) {
        this.id_cinema = id;
        this.nome_cinema = nome;
        this.endereco = local;
        this.salas = new ArrayList<>();
        cinemas.add(this);
    }

    public void criarSala(String nome, int capacidade) {
        Sala novaSala = new Sala(nome, capacidade);
        salas.add(novaSala);
    }

    public void listarSalas() {
        System.out.println("Salas do Cinema " + nome_cinema + ":");
        for (Sala sala : salas) {
            System.out.println(" - Sala: " + sala.getNome() + ", Capacidade: " + sala.getCapacidade());
        }
    }

    public static void listarCinemas() {
        System.out.println("Cinemas Criados:");
        for (Cinema cinema : cinemas) {
            System.out.println(" - ID: " + cinema.getId() + ", Nome: " + cinema.getNome() + ", Local: " + cinema.getLocal());
        }
    }

    public int getId() {
        return id_cinema;
    }

    public String getNome() {
        return nome_cinema;
    }

    public String getLocal() {
        return endereco;
    }
}
