package Cinemas;

public class CinemaBH extends Cinema {
    private static CinemaBH instancia;
    private final boolean estacionamentoGratuito; 

    private CinemaBH() {
        super(2, "Cinema BH", "Rua Tupis, 337, Belo Horizonte - MG");
        this.estacionamentoGratuito = true; 
    }

    public static CinemaBH getInstancia() {
        if (instancia == null) {
            instancia = new CinemaBH();
        }
        return instancia;
    }

    public boolean temEstacionamentoGratuito() {
        return estacionamentoGratuito;
    }
}
