package Cinemas;

import java.util.Random;

public class Coltecine extends Cinema {
    private static Coltecine instancia;
    private final int cashback; 
    private final Random random;

    private Coltecine() {
        super(3, "Coltecine", "Rua Eng. Caetano Lopes, 170, Belo Horizonte - MG");
        this.random = new Random();
        this.cashback = random.nextInt(5); 
    }

    public static Coltecine getInstancia() {
        if (instancia == null) {
            instancia = new Coltecine();
        }
        return instancia;
    }

    public int getCashback() {
        return cashback;
    }

    @Override
    public void listarSalas() {
        super.listarSalas();
        System.out.println("Cashback oferecido pelo Coltecine: " + cashback + "%");
    }
}

