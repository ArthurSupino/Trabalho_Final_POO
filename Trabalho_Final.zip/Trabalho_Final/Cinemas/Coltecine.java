package Cinemas;

public class Coltecine extends Cinema {
    private static Coltecine instancia;
    private final String especialidade; 

    private Coltecine() {
        super(3, "Coltecine", "Rua Eng. Caetano Lopes, 170, Belo Horizonte - MG");
        this.especialidade = "Filmes independentes e festivais de cinema";
    }

    public static Coltecine getInstancia() {
        if (instancia == null) {
            instancia = new Coltecine();
        }
        return instancia;
    }

    public String getEspecialidade() {
        return especialidade;
    }
}
