package Classes.Cinemas;

public class CinemaBH extends Cinema {
    private static CinemaBH instancia;
    private final boolean estacionamentoGratuito; 

    private CinemaBH() {
        super(2, "Cinema BH", "Rua Tupis, 337, Belo Horizonte - MG");
        this.estacionamentoGratuito = true; 
        this.setAditional(estacionamentoGratuito ? "Estacionamento gratuito" : "Estacionamento pago");
    }

    public static CinemaBH getInstancia() {
        if (instancia == null) {
            instancia = new CinemaBH();
        }
        return instancia;
    }

    public boolean temEstacionamentoGratuito() {
        return estacionamentoGratuito;
    }
}
