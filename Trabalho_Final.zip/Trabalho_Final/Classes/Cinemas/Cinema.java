package Classes.Cinemas;
import java.util.ArrayList;
import java.util.List;

import Classes.Componentes_do_Cinema.*;

public abstract class Cinema {
    private int id;
    private String nome;
    private String endereco;
    private List<Sala> salas;
    private static List<Cinema> cinemas = new ArrayList<>();
    private String aditional;

    public Cinema(int id, String nome, String local) {
        this.id = id;
        this.nome = nome;
        this.endereco = local;
        this.salas = new ArrayList<>();
        cinemas.add(this);
    }

    public boolean criarSala(String nome, int capacidade) {
        Sala novaSala = new Sala(nome, capacidade);
        this.salas.add(novaSala);
        return novaSala != null;
    }

    public List<Sala> listarSalas() {
        System.out.println("Salas do Cinema " + nome + ":");
        for (Sala sala : salas) {
            System.out.println(" - Sala: " + sala.getNome() + ", Capacidade: " + sala.getCapacidade());
        }
        return salas;
    }
    
    public static List<Cinema> listarCinemas() {
        System.out.println("Cinemas Criados:");
        for (Cinema cinema : cinemas) {
            System.out.println(" - Cinema: " + cinema.nome + ", Endereço: " + cinema.endereco);
        }
        return cinemas;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public List<Sala> getSalas() {
        return salas;
    }

    public static List<Cinema> getCinemas() {
        return cinemas;
    }

   public String getAditional(){
        return aditional;
   }

    public void setAditional(String aditional) {
        this.aditional = aditional;
    }
}
