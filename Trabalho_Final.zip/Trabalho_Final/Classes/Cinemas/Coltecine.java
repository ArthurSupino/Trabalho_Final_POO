package Classes.Cinemas;

import java.util.Random;

import Classes.Componentes_do_Cinema.Sala;

import java.util.List;

public class Coltecine extends Cinema {
    private static Coltecine instancia;
    private final int cashback; 
    private final Random random;

    private Coltecine() {
        super(3, "Coltecine", "Rua Eng. Caetano Lopes, 170, Belo Horizonte - MG");
        this.random = new Random();
        this.cashback = random.nextInt(5);
        this.setAditional( "Cashback: " + this.cashback + "%");
    }

    public static synchronized Coltecine getInstance() {
        if (instancia == null) {
            instancia = new Coltecine();
        }
        return instancia;
    }

    public int getCashback() {
        return cashback;
    }

    @Override
    public List<Sala> listarSalas() {
        List<Sala> salas = super.listarSalas();
        System.out.println("Cashback oferecido pelo Coltecine: " + cashback + "%");
        return salas;
    }
}

