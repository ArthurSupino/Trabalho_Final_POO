package Classes.Componentes_do_Cinema;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Sessao {
    private static List<Sessao> sessoes = new ArrayList<>();
    private static int contador = 1;
    private int id;
    private Sala sala;
    private Filme filme;
    private LocalDateTime dataHora;
    private int cinemaId;
    private int salaId;

    public Sessao(Sala sala, Filme filme, LocalDateTime dataHora) {
        this.id = contador++;
        this.sala = sala;
        this.filme = filme;
        this.dataHora = dataHora;
        sessoes.add(this);
    }

    public Sessao() {
    }

    public int getId() {
        return id;
    }

    public Sala getSala() {
        return sala;
    }

    public Filme getFilme() {
        return filme;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public static int getContador() {
        return contador;
    }

    public static void setContador(int contador) {
        Sessao.contador = contador;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

    public void setFilme(Filme filme) {
        this.filme = filme;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public int getCinemaId() {
        return cinemaId;
    }

    public void setCinemaId(int cinemaId) {
        this.cinemaId = cinemaId;
    }

    public int getSalaId() {
        return salaId;
    }

    public void setSalaId(int salaId) {
        this.salaId = salaId;
    }

    // Método para verificar se a sessão está em andamento
    public boolean isEmAndamento() {
        LocalDateTime agora = LocalDateTime.now();
        LocalDateTime fimSessao = dataHora.plusSeconds(filme.getDuracaoEmSegundos());
        return agora.isAfter(dataHora) && agora.isBefore(fimSessao);
    }

    // Método para calcular a duração restante da sessão
    public Duration getDuracaoRestante() {
        LocalDateTime agora = LocalDateTime.now();
        LocalDateTime fimSessao = dataHora.plusSeconds(filme.getDuracaoEmSegundos());
        if (agora.isAfter(fimSessao)) {
            return Duration.ZERO;
        }
        return Duration.between(agora, fimSessao);
    }

    // Método para verificar se a sala da sessão está lotada
    public boolean isLotada() {
        for (Boolean assento : sala.listarAssentos().values()) // Se assento == true -> Disponível
            if (assento) return false;
        return true;
    }

    // Método para obter todas as sessões
    public static List<Sessao> getSessoes() {
        return new ArrayList<>(sessoes);
    }

    // Método para obter todas as sessões de um cinema específico
    public static List<Sessao> getSessoes(int cinemaId) {
        List<Sessao> sessoesFiltradas = new ArrayList<>();
        for (Sessao sessao : sessoes) {
            if (sessao.getCinemaId() == cinemaId) {
                sessoesFiltradas.add(sessao);
            }
        }
        return sessoesFiltradas;
    }

    // Método para obter um resumo detalhado da sessão
    public String toString() {
        return "Sessão ID: " + id + "\n" +
               "Filme: " + filme.getNome() + "\n" +
               "Sala: " + sala.getNome() + "\n" +
               "Data e Hora: " + dataHora + "\n" +
               "Duração Restante: " + getDuracaoRestante().toMinutes() + " minutos\n" +
               "Lotada: " + (isLotada() ? "Sim" : "Não");
    }
}
