package Classes.Componentes_do_Cinema;

import java.math.BigDecimal;

public class Ingresso {
    private int idIngresso;
    private int idVenda;
    private int idSessao;
    private int idSala;
    private int idCinema;
    private BigDecimal valor;
    private String assento;

    public Ingresso(int idVenda, int idSessao, int idSala, int idCinema, BigDecimal valor, String assento) {
        this.idVenda = idVenda;
        this.idSessao = idSessao;
        this.idSala = idSala;
        this.idCinema = idCinema;
        this.valor = valor;
        this.assento = assento;
    }

    public int getIdIngresso() {
        return idIngresso;
    }

    public void setIdIngresso(int idIngresso) {
        this.idIngresso = idIngresso;
    }

    public int getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    public int getIdSessao() {
        return idSessao;
    }

    public void setIdSessao(int idSessao) {
        this.idSessao = idSessao;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    public int getIdCinema() {
        return idCinema;
    }

    public void setIdCinema(int idCinema) {
        this.idCinema = idCinema;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public String getAssento() {
        return assento;
    }

    public void setAssento(String assento) {
        this.assento = assento;
    }
}
