package Classes.Componentes_do_Cinema;

public class Filme {
    private int id;
    private int cinemaId;
    private int salaId;
    private int sessaoId;
    private String nome;
    private long duracao_s;

    public Filme(int id, String nome, long duracao_s) {
        this.id = id;
        this.nome = nome;
        this.duracao_s = duracao_s;
    }

    public Filme() {
    }        

    public int getCinemaId() {
        return cinemaId;
    }



    public void setCinemaId(int cinemaId) {
        this.cinemaId = cinemaId;
    }



    public int getSalaId() {
        return salaId;
    }



    public void setSalaId(int salaId) {
        this.salaId = salaId;
    }



    public int getSessaoId() {
        return sessaoId;
    }



    public void setSessaoId(int sessaoId) {
        this.sessaoId = sessaoId;
    }



    public int getId() {
        return id;
    }



    public void setId(int id) {
        this.id = id;
    }



    public String getNome() {
        return nome;
    }



    public void setNome(String nome) {
        this.nome = nome;
    }



    public long getDuracao() {
        return duracao_s;
    }



    public void setDuracao(long duracao_s) {
        this.duracao_s = duracao_s;
    }



    public long getDuracaoEmSegundos() {
        return duracao_s;
    }

    public String getDuracaoFormatada() {
        long horas = duracao_s / 3600;
        long minutos = (duracao_s % 3600) / 60;
        long segundos = duracao_s % 60;
        return String.format("%02d:%02d:%02d", horas, minutos, segundos);
    }

    public String toString() {
        return "Filme ID: " + id + "\n" +
               "Nome: " + nome + "\n" +
               "Duração: " + getDuracaoFormatada();
    }
    
    // Método para comparar a duração de dois filmes
    public int compararDuracao(Filme outroFilme) {
        return Long.compare(this.duracao_s, outroFilme.getDuracaoEmSegundos());
    }
    
    // Método para verificar se o filme é uma longa-metragem (duração maior que 40 minutos)
    public boolean isLongaMetragem() {
        return this.duracao_s > 2400; // 40 minutos em segundos
    }
    
}
