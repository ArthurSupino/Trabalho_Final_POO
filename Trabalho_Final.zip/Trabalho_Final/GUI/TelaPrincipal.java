/*package GUI;

import DAO.CinemaDAO;
import DAO.SessaoDAO;
import Classes.Cinemas.Cinema;
import Classes.Componentes_do_Cinema.Sessao;
import Vendas.VendaIngresso;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.*;

import java.util.List;

public class TelaPrincipal extends Application {
    private CinemaDAO cinemaDAO = new CinemaDAO();
    private SessaoDAO sessaoDAO = new SessaoDAO();
    private ComboBox<Cinema> comboCinema;
    private ComboBox<Sessao> comboSessao;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Sistema de Compra de Ingressos");

        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));
        vbox.setAlignment(Pos.CENTER);

        Label labelCinema = new Label("Escolha o Cinema:");
        comboCinema = new ComboBox<>();
        comboCinema.getItems().addAll(cinemaDAO.listarTodos()); 
        comboCinema.setOnAction(e -> loadSessoes());

        Label labelSessao = new Label("Escolha a Sessão:");
        comboSessao = new ComboBox<>();

        Button btnProsseguir = new Button("Proseguir para Compra");
        btnProsseguir.setOnAction(e -> {
            Sessao sessaoSelecionada = comboSessao.getValue();
            if (sessaoSelecionada != null) {
                TelaCompra telaCompra = new TelaCompra(sessaoSelecionada);
                telaCompra.start(new Stage());
                primaryStage.close();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erro");
                alert.setHeaderText("Sessão não selecionada");
                alert.setContentText("Por favor, selecione uma sessão para continuar.");
                alert.showAndWait();
            }
        });

        vbox.getChildren().addAll(labelCinema, comboCinema, labelSessao, comboSessao, btnProsseguir);
        Scene scene = new Scene(vbox, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void loadSessoes() {
        Cinema cinemaSelecionado = comboCinema.getValue();
        if (cinemaSelecionado != null) {
            List<Sessao> sessoes = sessaoDAO.buscarSessoesPorCinema(cinemaSelecionado.getId());
            comboSessao.getItems().setAll(sessoes); 
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}*/
//Interface
