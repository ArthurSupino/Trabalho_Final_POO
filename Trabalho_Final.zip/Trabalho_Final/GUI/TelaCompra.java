/*package GUI;

import Vendas.VendaIngresso;
import Classes.Componentes_do_Cinema.Sessao;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.*;

public class TelaCompra extends Application {
    private Sessao sessao;
    private int quantidadeIngressos = 1; 

    public TelaCompra(Sessao sessao) {
        this.sessao = sessao;
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Comprar Ingresso");

        // Layout
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));
        vbox.setAlignment(Pos.CENTER);

        Label labelSessao = new Label("Sessão: " + sessao.getNome());
        
        Label labelQuantidade = new Label("Quantos ingressos?");
        Spinner<Integer> spinnerQuantidade = new Spinner<>(1, 10, 1);
        
        Label labelAssento = new Label("Escolha o(s) assento(s):");
        TextField inputAssentos = new TextField();
        inputAssentos.setPromptText("Exemplo: A1, A2");
        
        Button btnFinalizarCompra = new Button("Finalizar Compra");
        btnFinalizarCompra.setOnAction(e -> {
            String assentos = inputAssentos.getText();
            if (!assentos.isEmpty()) {
                VendaIngresso venda = new VendaIngresso(sessao);
                venda.setAssentoEscolhido(assentos);
                venda.setValorTotal(venda.getPrecoIngresso().multiply(new BigDecimal(quantidadeIngressos)));
                
                try {
                    VendaIngressoDAO vendaDAO = new VendaIngressoDAO();
                    vendaDAO.addVendaIngresso(venda);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Compra Realizada");
                    alert.setHeaderText("Compra finalizada com sucesso!");
                    alert.setContentText("Total: " + venda.getValorTotal());
                    alert.showAndWait();
                    primaryStage.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Erro");
                alert.setHeaderText("Assento não selecionado");
                alert.setContentText("Por favor, escolha um assento.");
                alert.showAndWait();
            }
        });

        vbox.getChildren().addAll(labelSessao, labelQuantidade, spinnerQuantidade, labelAssento, inputAssentos, btnFinalizarCompra);
        Scene scene = new Scene(vbox, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}*/
//Interface 
