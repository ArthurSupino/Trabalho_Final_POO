import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Classes.Cinemas.Cinema;
import Classes.Cinemas.CinemaBH;
import Classes.Cinemas.CinemaDelRey;
import Classes.Cinemas.Coltecine;
import Classes.Componentes_do_Cinema.Sala;
import Classes.Componentes_do_Cinema.Sessao;
import netscape.javascript.JSObject;

public class JavaConnector {
    private JSObject jsObject;

    public void setJsObject(JSObject jsObject) {
        this.jsObject = jsObject;
    }

        // Listar cinemas
    public void listarCinemas() {

        CinemaBH.getInstancia();
        CinemaDelRey.getInstancia();
        Coltecine.getInstance();

        Cinema.listarCinemas();

        System.out.println("Function listarCinemas executed!");

        List<String> cinemaNames = new ArrayList<>();
        for (Cinema cinema : Cinema.getCinemas()) {
            System.out.println(cinema.getNome());
            cinemaNames.add(cinema.getNome());
        }
        jsObject.call("updateCinemas", cinemaNames);
    }

    // Mostrar sessões disponíveis
    public void getSessoes() {
        List<Map<String, String>> sessoesInfo = new ArrayList<>();
        for (Sessao sessao : Sessao.getSessoes(2)) {
            Map<String, String> info = new HashMap<>();
            info.put("filme", sessao.getFilme().getNome());
            info.put("dataHora", sessao.getDataHora().toString());
            info.put("salaId", String.valueOf(sessao.getSalaId()));
            sessoesInfo.add(info);
        }
        jsObject.call("updateSessoes", sessoesInfo);
    }

    // Mostrar assentos disponíveis
    public void listarAssentos() {
        jsObject.call("updateAssentos", 5);
    }


    public void comprarIngresso() {
        System.out.println("Function comprarIngresso executed!");
        jsObject.call("updateOutput", "Function comprarIngresso executed!");
    }

    public void cadastrarIngresso() {
        System.out.println("Function cadastrarIngresso executed!");
        jsObject.call("updateOutput", "Function cadastrarIngresso executed!");
    }

    public void cadastrarFilme() {
        System.out.println("Function cadastrarFilme executed!");
        jsObject.call("updateOutput", "Function cadastrarFilme executed!");
    }

    public void cadastrarSessao() {
        System.out.println("Function cadastrarSessao executed!");
        jsObject.call("updateOutput", "Function cadastrarSessao executed!");
    }

    public void cadastrarSala() {
        System.out.println("Function cadastrarSala executed!");
        jsObject.call("updateOutput", "Function cadastrarSala executed!");
    }
}
