package Vendas;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import Componentes_do_Cinema.*;
import Cinemas.*;

public class VendaIngressos implements Runnable {
    private Sala sala;
    private Map<String, Integer> assentosEscolhidos; 
    private int totalCompra;
    private final int precoIngresso = 30; 
    private static final int tempoProcessamentoCompra = 3000; 

    public VendaIngressos(Sala sala) {
        this.sala = sala;
        this.assentosEscolhidos = new HashMap<>();
        this.totalCompra = 0;
    }

    public void listarAssentosDisponiveis() {
        System.out.println("Assentos Disponíveis na Sala " + sala.getNome() + ":");
        sala.listarAssentos();
    }

    public void escolherAssento(String assento) {
        if (sala.isAssentoDisponivel(assento)) {
            assentosEscolhidos.put(assento, precoIngresso);
            sala.marcarAssentoComoOcupado(assento);
            System.out.println("Assento " + assento + " escolhido com sucesso.");
        } else {
            System.out.println("Assento " + assento + " já está ocupado ou não existe.");
        }
    }

    public void calcularTotal() {
        totalCompra = assentosEscolhidos.size() * precoIngresso;
        System.out.println("Valor Total da Compra: R$ " + totalCompra);
    }

    public void realizarCompra() {
        System.out.println("Processando a compra...");
        try {
            Thread.sleep(tempoProcessamentoCompra);
            System.out.println("Compra finalizada com sucesso!");
            System.out.println("Total pago: R$ " + totalCompra);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        realizarCompra();
    }
}