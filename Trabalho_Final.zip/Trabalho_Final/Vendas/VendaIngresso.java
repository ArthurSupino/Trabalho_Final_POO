package Vendas;
import java.util.Map;
import java.util.Scanner;
import java.math.BigDecimal;

import Classes.Cinemas.*;
import Classes.Componentes_do_Cinema.*;

public class VendaIngresso implements Runnable {
    private int idVenda;
    private int idSessao;
    private int idSala;
    private int idCinema;
    private Sessao sessao;
    private String assentoEscolhido; 
    private BigDecimal valorTotal;
    private final int precoIngresso = 30; 
    private static final int tempoProcessamentoCompra = 3000;


    public VendaIngresso(Sessao sessao) {
        this.idSessao = sessao.getId();
        this.idSala = sessao.getSala().getId();
        this.idCinema = sessao.getCinemaId();
        this.sessao = sessao;;
        this.valorTotal = BigDecimal.ZERO;
    }

    public VendaIngresso(int idVenda, int idSessao, int idSala, int idCinema, BigDecimal valorTotal, String assentoEscolhido) {
        this.idSessao = sessao.getId();
        this.idSala = sessao.getSala().getId();
        this.idCinema = sessao.getCinemaId();
        this.sessao = (new DAO.SessaoDAO()).buscarSessaoPorId(idSessao, idSala, idCinema);
        this.assentoEscolhido = assentoEscolhido;
        this.valorTotal = BigDecimal.ZERO;
    }

    // Getters and setters
    // Constructor

    

    public int getIdVenda() {
        return idVenda;
    }



    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }



    public int getIdSessao() {
        return idSessao;
    }



    public void setIdSessao(int idSessao) {
        this.idSessao = idSessao;
    }



    public int getIdSala() {
        return idSala;
    }



    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }



    public int getIdCinema() {
        return idCinema;
    }



    public void setIdCinema(int idCinema) {
        this.idCinema = idCinema;
    }



    public Sessao getSessao() {
        return sessao;
    }



    public void setSessao(Sessao sessao) {
        this.sessao = sessao;
    }



    public String getAssentoEscolhido() {
        return assentoEscolhido;
    }



    public void setAssentoEscolhido(String assentoEscolhido) {
        this.assentoEscolhido = assentoEscolhido;
    }





    public BigDecimal getValorTotal() {
        return valorTotal;
    }



    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }



    public int getPrecoIngresso() {
        return precoIngresso;
    }



    public static int getTempoprocessamentocompra() {
        return tempoProcessamentoCompra;
    }



    public void listarAssentosDisponiveis() {
        System.out.println("Assentos Disponíveis na Sala " + sessao.getSala().getNome() + ":");
        sessao.getSala().listarAssentos();
    }

    public void escolherAssento(String assento) {
        if (sessao.getSala().isAssentoDisponivel(assento)) {
            sessao.getSala().marcarAssentoComoOcupado(assento);
            sessao.getSala().marcarAssentoComoOcupado(assento);
            System.out.println("Assento " + assento + " escolhido com sucesso.");
        } else {
            System.out.println("Assento " + assento + " já está ocupado ou não existe.");
        }
    }

    public void realizarCompra() {
        System.out.println("Processando a compra...");
        try {
            Thread.sleep(tempoProcessamentoCompra);
            System.out.println("Compra finalizada com sucesso!");
            System.out.println("Total pago: R$ " + valorTotal);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        realizarCompra();
    }
}