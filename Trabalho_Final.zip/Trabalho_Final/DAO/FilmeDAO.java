package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Classes.Componentes_do_Cinema.*;

public class FilmeDAO {

    public void criarTabelaFilme() {
        String sql = "CREATE TABLE IF NOT EXISTS `mydb`.`Filme` ("
            + "`idFilme` INT NOT NULL AUTO_INCREMENT,"
            + "`nome` VARCHAR(45) NULL,"
            + "`duracao` BIGINT NULL,"
            + "`Sessao_idSessao` INT NOT NULL,"
            + "`Sessao_Sala_idSala` INT NOT NULL,"
            + "`Sessao_Sala_Cinema_idCinema` INT NOT NULL,"
            + "PRIMARY KEY (`idFilme`, `Sessao_idSessao`, `Sessao_Sala_idSala`, `Sessao_Sala_Cinema_idCinema`),"
            + "INDEX `fk_Filme_Sessao1_idx` (`Sessao_idSessao` ASC, `Sessao_Sala_idSala` ASC, `Sessao_Sala_Cinema_idCinema` ASC) VISIBLE,"
            + "CONSTRAINT `fk_Filme_Sessao1`"
            + "FOREIGN KEY (`Sessao_idSessao` , `Sessao_Sala_idSala` , `Sessao_Sala_Cinema_idCinema`)"
            + "REFERENCES `mydb`.`Sessao` (`idSessao` , `Sala_idSala` , `Sala_Cinema_idCinema`)"
            + "ON DELETE NO ACTION"
            + "ON UPDATE NO ACTION)"
            + "ENGINE = InnoDB;";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void inserirFilme(Filme filme) {
        String sql = "INSERT INTO Filme (nome, duracao, Sessao_idSessao, Sessao_Sala_idSala, Sessao_Sala_Cinema_idCinema) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, filme.getNome());
            stmt.setLong(2, filme.getDuracao());
            stmt.setInt(3, filme.getSessaoId());
            stmt.setInt(4, filme.getSalaId());
            stmt.setInt(5, filme.getCinemaId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void atualizarFilme(Filme filme) {
        String sql = "UPDATE Filme SET nome = ?, duracao = ? WHERE idFilme = ? AND Sessao_idSessao = ? AND Sessao_Sala_idSala = ? AND Sessao_Sala_Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, filme.getNome());
            stmt.setLong(2, filme.getDuracao());
            stmt.setInt(3, filme.getId());
            stmt.setInt(4, filme.getSessaoId());
            stmt.setInt(5, filme.getSalaId());
            stmt.setInt(6, filme.getCinemaId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletarFilme(int id, int sessaoId, int salaId, int cinemaId) {
        String sql = "DELETE FROM Filme WHERE idFilme = ? AND Sessao_idSessao = ? AND Sessao_Sala_idSala = ? AND Sessao_Sala_Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setInt(2, sessaoId);
            stmt.setInt(3, salaId);
            stmt.setInt(4, cinemaId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Filme buscarFilmePorId(int id, int sessaoId, int salaId, int cinemaId) {
        String sql = "SELECT * FROM Filme WHERE idFilme = ? AND Sessao_idSessao = ? AND Sessao_Sala_idSala = ? AND Sessao_Sala_Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setInt(2, sessaoId);
            stmt.setInt(3, salaId);
            stmt.setInt(4, cinemaId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Filme filme = new Filme();
                filme.setId(rs.getInt("idFilme"));
                filme.setNome(rs.getString("nome"));
                filme.setDuracao(rs.getLong("duracao"));
                filme.setSessaoId(rs.getInt("Sessao_idSessao"));
                filme.setSalaId(rs.getInt("Sessao_Sala_idSala"));
                filme.setCinemaId(rs.getInt("Sessao_Sala_Cinema_idCinema"));
                return filme;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Filme> listarFilmes() {
        List<Filme> filmes = new ArrayList<>();
        String sql = "SELECT * FROM Filme";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Filme filme = new Filme();
                filme.setId(rs.getInt("idFilme"));
                filme.setNome(rs.getString("nome"));
                filme.setDuracao(rs.getLong("duracao"));
                filme.setSessaoId(rs.getInt("Sessao_idSessao"));
                filme.setSalaId(rs.getInt("Sessao_Sala_idSala"));
                filme.setCinemaId(rs.getInt("Sessao_Sala_Cinema_idCinema"));
                filmes.add(filme);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return filmes;
    }
}