package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Vendas.VendaIngresso;

public class VendaIngressoDAO {
    private Connection connection;

    public VendaIngressoDAO(Connection connection) {
        this.connection = connection;
    }

    public void createTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS VendaIngresso (" +
                     "idVenda INT PRIMARY KEY AUTO_INCREMENT, " +
                     "idSessao INT NOT NULL, " +
                     "idSala INT NOT NULL, " +
                     "idCinema INT NOT NULL, " +
                     "assento VARCHAR(10) NOT NULL, " +
                     "valorTotal DECIMAL(10, 2) NOT NULL)";
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
    }

    public void addVendaIngresso(VendaIngresso vendaIngresso) throws SQLException {
        String sql = "INSERT INTO VendaIngresso (idSessao, idSala, idCinema, valorTotal) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, vendaIngresso.getIdSessao());
            stmt.setInt(2, vendaIngresso.getIdSala());
            stmt.setInt(3, vendaIngresso.getIdCinema());
            stmt.setBigDecimal(4, vendaIngresso.getValorTotal());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    vendaIngresso.setIdVenda(generatedKeys.getInt(1));
                }
            }
        }
    }

    public VendaIngresso getVendaIngresso(int idVenda) throws SQLException {
        String sql = "SELECT * FROM VendaIngresso WHERE idVenda = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idVenda);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new VendaIngresso(
                        rs.getInt("idVenda"),
                        rs.getInt("idSessao"),
                        rs.getInt("idSala"),
                        rs.getInt("idCinema"),
                        rs.getBigDecimal("valorTotal"),
                        rs.getString("assento")
                    );
                }
            }
        }
        return null;
    }

    public List<VendaIngresso> getAllVendaIngressos() throws SQLException {
        List<VendaIngresso> vendaIngressos = new ArrayList<>();
        String sql = "SELECT * FROM VendaIngresso";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                vendaIngressos.add(new VendaIngresso(
                    rs.getInt("idVenda"),
                    rs.getInt("idSessao"),
                    rs.getInt("idSala"),
                    rs.getInt("idCinema"),
                    rs.getBigDecimal("valorTotal"),
                    rs.getString("assento")
                ));
            }
        }
        return vendaIngressos;
    }

    public void updateVendaIngresso(VendaIngresso vendaIngresso) throws SQLException {
        String sql = "UPDATE VendaIngresso SET idSessao = ?, idSala = ?, idCinema = ?, valorTotal = ? WHERE idVenda = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vendaIngresso.getIdSessao());
            stmt.setInt(2, vendaIngresso.getIdSala());
            stmt.setInt(3, vendaIngresso.getIdCinema());
            stmt.setBigDecimal(4, vendaIngresso.getValorTotal());
            stmt.setInt(5, vendaIngresso.getIdVenda());
            stmt.executeUpdate();
        }
    }

    public void deleteVendaIngresso(int idVenda) throws SQLException {
        String sql = "DELETE FROM VendaIngresso WHERE idVenda = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idVenda);
            stmt.executeUpdate();
        }
    }
}