package DAO;

import java.sql.*;

public class Conexao {
	private static final String URL = "jdbc:mysql://localhost:3306/mydb";
	private static final String USER = "vitornms";
	private static final String PASSWORD = "9841";

	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			return DriverManager.getConnection(URL, USER, PASSWORD);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Erro ao conectar ao banco de dados", e);
		}
	}

	public static void closeConnection(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException("Erro ao fechar a conexão com o banco de dados", e);
			}
		}
	}
}