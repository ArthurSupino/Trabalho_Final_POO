package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Classes.Componentes_do_Cinema.*;

public class SalaDAO {

    public void criarTabelaSala() {
        String sql = "CREATE TABLE IF NOT EXISTS `mydb`.`Sala` (\r\n" + //
                        "  `idSala` INT NOT NULL AUTO_INCREMENT,\r\n" + //
                        "  `nome` VARCHAR(45) NULL,\r\n" + //
                        "  `capacidade` INT NULL,\r\n" + //
                        "  `Cinema_idCinema` INT NOT NULL,\r\n" + //
                        "  PRIMARY KEY (`idSala`, `Cinema_idCinema`),\r\n" + //
                        "  INDEX `fk_Sala_Cinema_idx` (`Cinema_idCinema` ASC) VISIBLE,\r\n" + //
                        "  CONSTRAINT `fk_Sala_Cinema`\r\n" + //
                        
                        "    FOREIGN KEY (`Cinema_idCinema`)\r\n" + //
                        "    REFERENCES `mydb`.`Cinema` (`idCinema`)\r\n" + //
                        "    ON DELETE NO ACTION\r\n" + //
                        "    ON UPDATE NO ACTION)\r\n" + //
                        "ENGINE = InnoDB;";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void inserirSala(Sala sala) {
        String sql = "INSERT INTO Sala (nome, capacidade, Cinema_idCinema) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, sala.getNome());
            stmt.setInt(2, sala.getCapacidade());
            stmt.setInt(3, sala.getCinemaId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void atualizarSala(Sala sala) {
        String sql = "UPDATE Sala SET nome = ?, capacidade = ? WHERE idSala = ? AND Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, sala.getNome());
            stmt.setInt(2, sala.getCapacidade());
            stmt.setInt(3, sala.getId());
            stmt.setInt(4, sala.getCinemaId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletarSala(int id, int cinemaId) {
        String sql = "DELETE FROM Sala WHERE idSala = ? AND Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setInt(2, cinemaId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Sala buscarSalaPorId(int id, int cinemaId) {
        String sql = "SELECT * FROM Sala WHERE idSala = ? AND Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setInt(2, cinemaId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Sala sala = new Sala();
                sala.setId(rs.getInt("idSala"));
                sala.setNome(rs.getString("nome"));
                sala.setCapacidade(rs.getInt("capacidade"));
                sala.setCinemaId(rs.getInt("Cinema_idCinema"));
                return sala;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Sala> listarSalas() {
        List<Sala> salas = new ArrayList<>();
        String sql = "SELECT * FROM Sala";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Sala sala = new Sala();
                sala.setId(rs.getInt("idSala"));
                sala.setNome(rs.getString("nome"));
                sala.setCapacidade(rs.getInt("capacidade"));
                sala.setCinemaId(rs.getInt("Cinema_idCinema"));
                salas.add(sala);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return salas;
    }
}
