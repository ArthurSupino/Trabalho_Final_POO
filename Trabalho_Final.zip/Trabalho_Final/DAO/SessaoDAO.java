package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import Classes.Componentes_do_Cinema.Sessao;

public class SessaoDAO {

    public void criarTabelaSessao() {
        String sql = "CREATE TABLE IF NOT EXISTS `mydb`.`Sessao` ("
                + "`idSessao` INT NOT NULL AUTO_INCREMENT,"
                + "`data` DATETIME NULL,"
                + "`Sala_idSala` INT NOT NULL,"
                + "`Sala_Cinema_idCinema` INT NOT NULL,"
                + "PRIMARY KEY (`idSessao`, `Sala_idSala`, `Sala_Cinema_idCinema`),"
                + "INDEX `fk_Sessao_Sala1_idx` (`Sala_idSala` ASC, `Sala_Cinema_idCinema` ASC) VISIBLE,"
                + "CONSTRAINT `fk_Sessao_Sala1`"
                + "FOREIGN KEY (`Sala_idSala` , `Sala_Cinema_idCinema`)"
                + "REFERENCES `mydb`.`Sala` (`idSala` , `Cinema_idCinema`)"
                + "ON DELETE NO ACTION"
                + "ON UPDATE NO ACTION)"
                + "ENGINE = InnoDB;";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void inserirSessao(Sessao sessao) {
        String sql = "INSERT INTO Sessao (data, Sala_idSala, Sala_Cinema_idCinema) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setTimestamp(1, Timestamp.valueOf(sessao.getDataHora()));
            stmt.setInt(2, sessao.getSalaId());
            stmt.setInt(3, sessao.getCinemaId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void atualizarSessao(Sessao sessao) {
        String sql = "UPDATE Sessao SET data = ? WHERE idSessao = ? AND Sala_idSala = ? AND Sala_Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setTimestamp(1, Timestamp.valueOf(sessao.getDataHora()));
            stmt.setInt(2, sessao.getId());
            stmt.setInt(3, sessao.getSalaId());
            stmt.setInt(4, sessao.getCinemaId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletarSessao(int id, int salaId, int cinemaId) {
        String sql = "DELETE FROM Sessao WHERE idSessao = ? AND Sala_idSala = ? AND Sala_Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setInt(2, salaId);
            stmt.setInt(3, cinemaId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Sessao buscarSessaoPorId(int id, int salaId, int cinemaId) {
        String sql = "SELECT * FROM Sessao WHERE idSessao = ? AND Sala_idSala = ? AND Sala_Cinema_idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setInt(2, salaId);
            stmt.setInt(3, cinemaId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Sessao sessao = new Sessao();
                sessao.setId(rs.getInt("idSessao"));
                sessao.setDataHora(rs.getTimestamp("data").toLocalDateTime());
                sessao.setSalaId(rs.getInt("Sala_idSala"));
                sessao.setCinemaId(rs.getInt("Sala_Cinema_idCinema"));
                return sessao;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Sessao> listarSessoes() {
        List<Sessao> sessoes = new ArrayList<>();
        String sql = "SELECT * FROM Sessao";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Sessao sessao = new Sessao();
                sessao.setId(rs.getInt("idSessao"));
                sessao.setDataHora(rs.getTimestamp("data").toLocalDateTime());
                sessao.setSalaId(rs.getInt("Sala_idSala"));
                sessao.setCinemaId(rs.getInt("Sala_Cinema_idCinema"));
                sessoes.add(sessao);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sessoes;
    }
}
