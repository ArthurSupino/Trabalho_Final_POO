package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Classes.Cinemas.*;

public class CinemaDAO {

    public void criarTabelaCinema() {
        String sql = "CREATE TABLE IF NOT EXISTS Cinema (" +
            "idCinema INTEGER PRIMARY KEY AUTOINCREMENT," +
            "nome TEXT NOT NULL," +
            "endereco TEXT NOT NULL," +
            "aditional TEXT" +
        ")";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void inserirCinema(Cinema cinema) {
        String sql = "INSERT INTO Cinema (nome, endereco, aditional) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cinema.getNome());
            stmt.setString(2, cinema.getEndereco());
            stmt.setString(3, cinema.getAditional());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void atualizarCinema(Cinema cinema) {
        String sql = "UPDATE Cinema SET nome = ?, endereco = ?, aditional = ? WHERE idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, cinema.getNome());
            stmt.setString(2, cinema.getEndereco());
            stmt.setString(3, cinema.getAditional());
            stmt.setInt(4, cinema.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletarCinema(int id) {
        String sql = "DELETE FROM Cinema WHERE idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Cinema buscarCinemaPorId(int id) {
        String sql = "SELECT * FROM Cinema WHERE idCinema = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int idCinema = rs.getInt("idCinema");
                String aditional = rs.getString("aditional");

                Cinema cinema = null;

                for (Cinema c : Cinema.getCinemas()) {
                    if (c.getId() == idCinema) {
                        cinema = c;
                        break;
                    }
                }

                cinema.setAditional(aditional);

                return cinema;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Cinema> listarCinemas() {
        List<Cinema> cinemas = new ArrayList<>();
        String sql = "SELECT * FROM Cinema";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int idCinema = rs.getInt("idCinema");
                String nome = rs.getString("nome");
                String endereco = rs.getString("endereco");
                String aditional = rs.getString("aditional");

                Cinema cinema = null;

                for (Cinema c : Cinema.getCinemas()) {
                    if (c.getId() == idCinema) {
                        cinema = c;
                        break;
                    }
                }
                cinema.setAditional(aditional);

                cinemas.add(cinema);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cinemas;
    }
}