package Componentes_do_Cinema;

public class Filme {
    private int id;
    private String nome;
    private long duracao_s;

    public Filme(int id, String nome, long duracao_s) {
        this.id = id;
        this.nome = nome;
        this.duracao_s = duracao_s;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public long getDuracaoEmSegundos() {
        return duracao_s;
    }

    public String getDuracaoFormatada() {
        long horas = duracao_s / 3600;
        long minutos = (duracao_s % 3600) / 60;
        long segundos = duracao_s % 60;
        return String.format("%02d:%02d:%02d", horas, minutos, segundos);
    }

    public String toString() {
        return "Filme ID: " + id + "\n" +
               "Nome: " + nome + "\n" +
               "Duração: " + getDuracaoFormatada();
    }
}
