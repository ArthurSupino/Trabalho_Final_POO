package Componentes_do_Cinema;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Sala {
    private String nome;
    private int capacidade;
    private List<Sessao> sessoes;

    public Sala(String nome, int capacidade) {
        this.nome = nome;
        this.capacidade = capacidade;
        this.sessoes = new ArrayList<>();
    }

    public void criarSessao(Filme filme, LocalDateTime dataHora) {
        Sessao novaSessao = new Sessao( this, filme, dataHora);
        sessoes.add(novaSessao);
        System.out.println("Sessão criada: " + filme.getNome() + " em " + dataHora);
    }

    public void listarSessoes() {
        System.out.println("Sessões na sala " + nome + ":");
        for (Sessao sessao : sessoes) {
            System.out.println(" - Filme: " + sessao.getFilme().getNome() + 
                               ", Data e Hora: " + sessao.getDataHora());
        }
    }

    public String getNome() {
        return nome;
    }

    public int getCapacidade() {
        return capacidade;
    }
}
