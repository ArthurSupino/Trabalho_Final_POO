package Componentes_do_Cinema;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Sala {
    private String nome;
    private int capacidade;
    private List<Sessao> sessoes;
    private Map<String, Boolean> assentos;

    public Sala(String nome, int capacidade) {
        this.nome = nome;
        this.capacidade = capacidade;
        this.sessoes = new ArrayList<>();
        this.assentos = new HashMap<>();
        gerarAssentos();
    }

    private void gerarAssentos() {
        int fileira = 1;
        int assentoPorFileira = 10;  
        int totalAssentos = capacidade;
        
        for (int i = 1; i <= totalAssentos; i++) {
           
            String chave = "Fileira " + fileira + ", Assento " + (i % assentoPorFileira == 0 ? assentoPorFileira : i % assentoPorFileira);
            assentos.put(chave, true);  
            if (i % assentoPorFileira == 0) {
                fileira++; 
            }
        }
    }

    public void criarSessao(Filme filme, LocalDateTime dataHora) {
        Sessao novaSessao = new Sessao(this, filme, dataHora);
        sessoes.add(novaSessao);
        System.out.println("Sessão criada: " + filme.getNome() + " em " + dataHora);
    }

    public void listarSessoes() {
        System.out.println("Sessões na sala " + nome + ":");
        for (Sessao sessao : sessoes) {
            System.out.println(" - Filme: " + sessao.getFilme().getNome() + 
                               ", Data e Hora: " + sessao.getDataHora());
        }
    }

    public void listarAssentos() {
        System.out.println("Assentos na sala " + nome + ":");
        for (Map.Entry<String, Boolean> entry : assentos.entrySet()) {
            String status = entry.getValue() ? "Disponível" : "Ocupado";
            System.out.println(" - " + entry.getKey() + ": " + status);
        }
    }

    public boolean isAssentoDisponivel(String assento) {
        return assentos.containsKey(assento) && assentos.get(assento);
    }

    public void marcarAssentoComoOcupado(String assento) {
        if (assentos.containsKey(assento)) {
            assentos.put(assento, false);
            System.out.println("Assento " + assento + " marcado como ocupado.");
        } else {
            System.out.println("Assento " + assento + " não existe.");
        }
    }

    public boolean reservarAssento(String assento) {
        if (isAssentoDisponivel(assento)) {
            marcarAssentoComoOcupado(assento);  
            System.out.println("Assento " + assento + " reservado com sucesso.");
            return true;
        } else {
            System.out.println("Assento " + assento + " não está disponível.");
            return false;
        }
    }

    public boolean liberarAssento(String assento) {
        if (assentos.containsKey(assento) && !assentos.get(assento)) {
            assentos.put(assento, true);  
            System.out.println("Assento " + assento + " liberado com sucesso.");
            return true;
        } else {
            System.out.println("Assento " + assento + " já está disponível.");
            return false;
        }
    }

    public String getNome() {
        return nome;
    }

    public int getCapacidade() {
        return capacidade;
    }
}
