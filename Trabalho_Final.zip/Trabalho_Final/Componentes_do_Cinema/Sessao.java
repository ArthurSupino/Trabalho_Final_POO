package Componentes_do_Cinema;
import java.time.LocalDateTime;

public class Sessao {
    private static int contador = 1;
    private int id;
    private Sala sala;
    private Filme filme;
    private LocalDateTime dataHora;

    public Sessao(Sala sala, Filme filme, LocalDateTime dataHora) {
        this.id = contador++;
        this.sala = sala;
        this.filme = filme;
        this.dataHora = dataHora;
    }

    public int getId() {
        return id;
    }

    public Sala getSala() {
        return sala;
    }

    public Filme getFilme() {
        return filme;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public String toString() {
        return "Sessão ID: " + id + "\n" +
               "Filme: " + filme.getNome() + "\n" +
               "Sala: " + sala.getNome() + "\n" +
               "Data e Hora: " + dataHora;
    }
}
