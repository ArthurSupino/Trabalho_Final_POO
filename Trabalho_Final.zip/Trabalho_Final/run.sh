#!/bin/bash
# Caminhos para os diretórios e bibliotecas
JAVAFX_PATH="/home/arthur/Documents/POO/openjfx-23.0.1_linux-x64_bin-sdk/javafx-sdk-23.0.1/lib"
BIN_PATH="/home/arthur/Documents/POO/Trabalho_Final/bin"

# Compilação
javac --module-path $JAVAFX_PATH --add-modules=javafx.controls,javafx.web -d $BIN_PATH $(find . -name "*.java")

# Execução
java --module-path $JAVAFX_PATH --add-modules=javafx.controls,javafx.web -cp $BIN_PATH:$JAVAFX_PATH/javafx.controls.jar:$JAVAFX_PATH/javafx.web.jar GUI.TelaPrincipal
